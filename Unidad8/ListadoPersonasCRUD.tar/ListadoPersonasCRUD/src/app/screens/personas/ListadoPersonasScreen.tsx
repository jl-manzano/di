import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, TextInput } from 'react-native';
import { observer } from 'mobx-react-lite';
import { useRouter } from 'expo-router';
import { PersonasViewModel } from '../../../UI/ViewModels/PersonasViewModel';
import { PersonaListItem } from '../../../Components/PeopleListItem';
import { PersonaUIModel } from '../../../UI/Models/PersonaUIModel';

const ListadoPersonasScreen = observer(function ListadoPersonasScreen() {
  const viewModel = PersonasViewModel.getInstance();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    viewModel.loadPersonas();
  }, []);

  const handleAddPersona = () => {
    viewModel.selectPersona(null);
    router.push('/screens/personas/EditarInsertarPersonaScreen');
  };

  const handleEditPersona = (persona: PersonaUIModel) => {
    viewModel.selectPersona(persona);
    router.push('/screens/personas/EditarInsertarPersonaScreen');
  };

  const handleDeletePersona = (persona: PersonaUIModel) => {
    console.log('handleDeletePersona llamado para:', persona.nombre);
    
    const confirmacion = window.confirm(
      `¿Está seguro que desea eliminar a ${persona.nombre} ${persona.apellidos}?`
    );
    
    if (confirmacion) {
      console.log('Usuario confirmó eliminación');
      performDelete(persona.id);
    } else {
      console.log('Eliminación cancelada');
    }
  };

  const performDelete = async (id: number) => {
    console.log('performDelete iniciado para id:', id);
    try {
      await viewModel.deletePersona(id);
      console.log('Persona eliminada exitosamente');
    } catch (error) {
      console.error('Error al eliminar persona:', error);
      const errorMessage = error instanceof Error ? error.message : 'Error desconocido';
      window.alert(`Error: ${errorMessage}`);
    }
  };

  // Filtrar personas basándose en la búsqueda
  const filteredPersonas = viewModel.personas.filter(persona => {
    const fullName = `${persona.nombre} ${persona.apellidos}`.toLowerCase();
    const departamento = persona.nombreDepartamento.toLowerCase();
    const telefono = persona.telefono.toLowerCase();
    const query = searchQuery.toLowerCase();
    
    return fullName.includes(query) || 
           departamento.includes(query) || 
           telefono.includes(query);
  });

  if (viewModel.isLoading && viewModel.personas.length === 0) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#667eea" />
        <Text style={styles.loadingText}>Cargando personal...</Text>
      </View>
    );
  }

  if (viewModel.error) {
    return (
      <View style={styles.centerContainer}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorIcon}>⚠️</Text>
          <Text style={styles.errorText}>{viewModel.error}</Text>
          <TouchableOpacity 
            style={styles.retryButton} 
            onPress={() => viewModel.loadPersonas()}
          >
            <Text style={styles.retryText}>Reintentar</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.push('/')}
            activeOpacity={0.7}
          >
            <Text style={styles.backArrow}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Personal</Text>
        </View>
        <Text style={styles.headerSubtitle}>
          {filteredPersonas.length} persona{filteredPersonas.length !== 1 ? 's' : ''} registrada{filteredPersonas.length !== 1 ? 's' : ''}
          {searchQuery && ` (filtrada${filteredPersonas.length !== 1 ? 's' : ''})`}
        </Text>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Buscar por nombre, departamento o teléfono..."
            placeholderTextColor="#adb5bd"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity 
              onPress={() => setSearchQuery('')}
              style={styles.clearButton}
            >
              <Text style={styles.clearIcon}>✕</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      <FlatList
        data={filteredPersonas}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <PersonaListItem
            persona={item}
            onPress={() => handleEditPersona(item)}
            onDelete={() => handleDeletePersona(item)}
          />
        )}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>
              {searchQuery ? '🔍' : '👥'}
            </Text>
            <Text style={styles.emptyText}>
              {searchQuery 
                ? 'No se encontraron personas' 
                : 'No hay personas registradas'}
            </Text>
            <Text style={styles.emptySubtext}>
              {searchQuery 
                ? `No hay resultados para "${searchQuery}"` 
                : 'Toca el botón + para agregar la primera persona'}
            </Text>
          </View>
        }
      />
      
      <TouchableOpacity 
        style={styles.fab} 
        onPress={handleAddPersona}
        activeOpacity={0.8}
      >
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
});

export default ListadoPersonasScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    backgroundColor: '#667eea',
    paddingTop: 20,
    paddingBottom: 16,
    paddingHorizontal: 16,
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  backButton: {
    marginRight: 12,
    padding: 4,
  },
  backArrow: {
    fontSize: 28,
    color: '#fff',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
    marginLeft: 44,
  },
  searchContainer: {
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    borderRadius: 12,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  searchIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: '#1a1a2e',
  },
  clearButton: {
    padding: 4,
  },
  clearIcon: {
    fontSize: 18,
    color: '#6c757d',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#6c757d',
  },
  listContent: {
    padding: 16,
    paddingBottom: 100,
  },
  errorContainer: {
    alignItems: 'center',
    padding: 20,
  },
  errorIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  errorText: {
    color: '#dc3545',
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#667eea',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 12,
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  retryText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 20,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1a1a2e',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#6c757d',
    textAlign: 'center',
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#667eea',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  fabText: {
    color: '#fff',
    fontSize: 36,
    fontWeight: '300',
    lineHeight: 36,
  },
});