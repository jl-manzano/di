export interface PersonaConDepartamentoSeleccionado {
  idPersona: number;
  idDepartamentoSeleccionado: number;
}
